import os
import django

# Setup Django Environment
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'fooddelivery.settings')
django.setup()

from django.contrib.auth import get_user_model
from restaurant.models import Category, Restaurant, MenuItem
from orders.models import Cart

User = get_user_model()

def seed_db():
    print("Seeding database...")

    # 1. Create Superuser & Test User
    if not User.objects.filter(username="admin@fooddelivery.com").exists():
        admin = User.objects.create_superuser(
            username="admin@fooddelivery.com",
            email="admin@fooddelivery.com",
            password="adminpassword",
            first_name="Admin",
            last_name="User",
            phone="1234567890",
            address="123 Admin St, HQ"
        )
        print("Created superuser: admin@fooddelivery.com / adminpassword")
    else:
        print("Superuser already exists.")

    if not User.objects.filter(username="customer@fooddelivery.com").exists():
        customer = User.objects.create_user(
            username="customer@fooddelivery.com",
            email="customer@fooddelivery.com",
            password="customerpassword",
            first_name="John",
            last_name="Doe",
            phone="9876543210",
            address="456 Maple Avenue, Apt 4B, Metro City"
        )
        # Create a cart for them
        Cart.objects.get_or_create(user=customer)
        print("Created customer: customer@fooddelivery.com / customerpassword")
    else:
        print("Customer already exists.")

    # 2. Create Categories
    categories_data = [
        {"name": "Pizza", "slug": "pizza", "icon": "🍕", "description": "Hot, cheesy, and freshly baked pizzas."},
        {"name": "Burgers", "slug": "burgers", "icon": "🍔", "description": "Juicy burgers, wraps, and crispy fries."},
        {"name": "Salads", "slug": "salads", "icon": "🥗", "description": "Fresh, healthy, and organic green salads."},
        {"name": "Sushi", "slug": "sushi", "icon": "🍣", "description": "Authentic Japanese sushi rolls and sashimi."},
        {"name": "Desserts", "slug": "desserts", "icon": "🍰", "description": "Sweet treats, cakes, and ice creams."},
        {"name": "Beverages", "slug": "beverages", "icon": "🥤", "description": "Refreshing cold drinks, juices, and coffees."}
    ]

    categories = {}
    for cat in categories_data:
        obj, created = Category.objects.get_or_create(
            slug=cat["slug"],
            defaults={"name": cat["name"], "icon": cat["icon"], "description": cat["description"]}
        )
        categories[cat["slug"]] = obj
        if created:
            print(f"Created category: {cat['name']}")

    # 3. Create Restaurants
    restaurants_data = [
        {
            "name": "Pizza Palace",
            "description": "Authentic wood-fired Neapolitan pizzas with fresh mozzarella and premium toppings.",
            "address": "12 Pizza Blvd, Food District",
            "phone": "+91 99001 22334",
            "email": "contact@pizzapalace.com",
            "rating": 4.7,
            "delivery_time": "25-35 min",
            "minimum_order": 200.00
        },
        {
            "name": "Burger Bistro",
            "description": "Gourmet smash burgers, craft sauces, and hand-cut loaded fries.",
            "address": "45 Burger Lane, Midtown",
            "phone": "+91 99002 33445",
            "email": "orders@burgerbistro.com",
            "rating": 4.5,
            "delivery_time": "20-30 min",
            "minimum_order": 150.00
        },
        {
            "name": "The Green Garden",
            "description": "Healthy, organic salads, bowls, and cold-pressed juices for the fitness enthusiasts.",
            "address": "78 Wellness St, Green Park",
            "phone": "+91 99003 44556",
            "email": "hello@greengarden.com",
            "rating": 4.6,
            "delivery_time": "30-40 min",
            "minimum_order": 180.00
        },
        {
            "name": "Sushi Express",
            "description": "Freshly prepared sushi, maki rolls, ramen, and traditional Japanese dishes.",
            "address": "90 Tokyo Avenue, East Wing",
            "phone": "+91 99004 55667",
            "email": "sushi@express.com",
            "rating": 4.8,
            "delivery_time": "35-50 min",
            "minimum_order": 300.00
        }
    ]

    restaurants = {}
    for rest in restaurants_data:
        obj, created = Restaurant.objects.get_or_create(
            name=rest["name"],
            defaults=rest
        )
        restaurants[rest["name"]] = obj
        if created:
            print(f"Created restaurant: {rest['name']}")

    # 4. Create Menu Items
    menu_items_data = [
        # Pizza Palace Items
        {
            "restaurant": "Pizza Palace",
            "category": "pizza",
            "name": "Margherita Classica",
            "description": "Simple yet perfect: tomato sauce, fresh buffalo mozzarella, fresh basil, and extra virgin olive oil.",
            "price": 299.00,
            "is_vegetarian": True,
            "is_vegan": False,
            "is_featured": True,
            "calories": 750
        },
        {
            "restaurant": "Pizza Palace",
            "category": "pizza",
            "name": "Pepperoni Feast",
            "description": "Loaded with spicy Italian pepperoni, mozzarella cheese, and signature tomato herb sauce.",
            "price": 399.00,
            "is_vegetarian": False,
            "is_vegan": False,
            "is_featured": True,
            "calories": 950
        },
        {
            "restaurant": "Pizza Palace",
            "category": "pizza",
            "name": "Garden Special Veggie",
            "description": "Bell peppers, onions, sweet corn, mushrooms, black olives, and tomatoes with a sprinkle of oregano.",
            "price": 349.00,
            "is_vegetarian": True,
            "is_vegan": False,
            "is_featured": False,
            "calories": 800
        },
        {
            "restaurant": "Pizza Palace",
            "category": "beverages",
            "name": "Garlic Breadsticks",
            "description": "Freshly baked breadsticks brushed with garlic butter and served with creamy cheese dip.",
            "price": 129.00,
            "is_vegetarian": True,
            "is_vegan": False,
            "is_featured": False,
            "calories": 350
        },

        # Burger Bistro Items
        {
            "restaurant": "Burger Bistro",
            "category": "burgers",
            "name": "Classic Cheeseburger",
            "description": "Juicy flame-grilled beef patty, cheddar cheese, pickles, onions, lettuce, and secret house sauce.",
            "price": 199.00,
            "is_vegetarian": False,
            "is_vegan": False,
            "is_featured": True,
            "calories": 650
        },
        {
            "restaurant": "Burger Bistro",
            "category": "burgers",
            "name": "Spicy Crispy Chicken Burger",
            "description": "Crispy fried chicken breast fillet tossed in spicy cayenne glaze, with lettuce and jalapeno mayo.",
            "price": 249.00,
            "is_vegetarian": False,
            "is_vegan": False,
            "is_featured": True,
            "calories": 720
        },
        {
            "restaurant": "Burger Bistro",
            "category": "burgers",
            "name": "Double Trouble Smash Burger",
            "description": "Two smashed beef patties, double cheddar cheese, caramelized onions, and smoky BBQ sauce.",
            "price": 299.00,
            "is_vegetarian": False,
            "is_vegan": False,
            "is_featured": False,
            "calories": 900
        },
        {
            "restaurant": "Burger Bistro",
            "category": "burgers",
            "name": "Ultimate Veggie Delight Burger",
            "description": "Crispy mixed vegetable and potato patty, layered with cheese, fresh tomatoes, and spicy herb sauce.",
            "price": 179.00,
            "is_vegetarian": True,
            "is_vegan": False,
            "is_featured": False,
            "calories": 520
        },

        # The Green Garden Items
        {
            "restaurant": "The Green Garden",
            "category": "salads",
            "name": "Avocado & Quinoa Power Bowl",
            "description": "Organic red quinoa, fresh Hass avocado, cherry tomatoes, cucumbers, kale, roasted almonds, and lemon-tahini dressing.",
            "price": 279.00,
            "is_vegetarian": True,
            "is_vegan": True,
            "is_featured": True,
            "calories": 420
        },
        {
            "restaurant": "The Green Garden",
            "category": "salads",
            "name": "Mediterranean Caesar Salad",
            "description": "Crisp romaine lettuce, herb croutons, parmesan cheese, black olives, tossed in light Caesar dressing.",
            "price": 229.00,
            "is_vegetarian": True,
            "is_vegan": False,
            "is_featured": False,
            "calories": 310
        },
        {
            "restaurant": "The Green Garden",
            "category": "beverages",
            "name": "Cold-Pressed Green Juice",
            "description": "Freshly pressed spinach, cucumber, green apple, celery, and ginger juice. No added sugar.",
            "price": 149.00,
            "is_vegetarian": True,
            "is_vegan": True,
            "is_featured": False,
            "calories": 90
        },

        # Sushi Express Items
        {
            "restaurant": "Sushi Express",
            "category": "sushi",
            "name": "Salmon Avocado Roll (8 pcs)",
            "description": "Fresh Atlantic salmon, creamy avocado, and cucumber rolled in seasoned sushi rice, topped with sesame seeds.",
            "price": 499.00,
            "is_vegetarian": False,
            "is_vegan": False,
            "is_featured": True,
            "calories": 380
        },
        {
            "restaurant": "Sushi Express",
            "category": "sushi",
            "name": "California Gold Roll (8 pcs)",
            "description": "Crab stick, avocado, cucumber, rolled with orange tobiko caviar and spicy mayo drizzle.",
            "price": 429.00,
            "is_vegetarian": False,
            "is_vegan": False,
            "is_featured": False,
            "calories": 360
        },
        {
            "restaurant": "Sushi Express",
            "category": "sushi",
            "name": "Crunchy Veggie Tempura Roll (8 pcs)",
            "description": "Crispy sweet potato and zucchini tempura rolled with avocado, drizzled with sweet unagi glaze.",
            "price": 349.00,
            "is_vegetarian": True,
            "is_vegan": True,
            "is_featured": True,
            "calories": 320
        },

        # General Desserts (available at Burger Bistro for simplicity)
        {
            "restaurant": "Burger Bistro",
            "category": "desserts",
            "name": "Warm Chocolate Fudge Brownie",
            "description": "Rich, decadent chocolate brownie served warm with a gooey center.",
            "price": 119.00,
            "is_vegetarian": True,
            "is_vegan": False,
            "is_featured": True,
            "calories": 480
        },
        {
            "restaurant": "The Green Garden",
            "category": "desserts",
            "name": "Vegan Chia Seed Pudding",
            "description": "Coconut milk chia pudding layered with fresh strawberry puree and almond flakes.",
            "price": 139.00,
            "is_vegetarian": True,
            "is_vegan": True,
            "is_featured": False,
            "calories": 210
        }
    ]

    for item in menu_items_data:
        restaurant_obj = restaurants[item["restaurant"]]
        category_obj = categories[item["category"]]
        obj, created = MenuItem.objects.get_or_create(
            restaurant=restaurant_obj,
            name=item["name"],
            defaults={
                "category": category_obj,
                "description": item["description"],
                "price": item["price"],
                "is_vegetarian": item["is_vegetarian"],
                "is_vegan": item["is_vegan"],
                "is_featured": item["is_featured"],
                "calories": item["calories"],
                "is_available": True
            }
        )
        if created:
            print(f"Created menu item: {item['name']} ({item['restaurant']})")

    print("Seeding completed successfully! *")

if __name__ == '__main__':
    seed_db()
