import os
import django

# Setup Django Environment
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'fooddelivery.settings')
django.setup()

from restaurant.models import Restaurant, MenuItem

def update_db_images():
    print("Updating database references with 4K & HD food images...")

    # 1. Update Restaurant images
    restaurants_images = {
        "Pizza Palace": "restaurants/pizza_palace.png",
        "Burger Bistro": "restaurants/burger_bistro.png",
        "The Green Garden": "restaurants/green_garden.png",
        "Sushi Express": "restaurants/sushi_express.png",
    }

    for name, img_path in restaurants_images.items():
        try:
            rest = Restaurant.objects.get(name=name)
            rest.image = img_path
            rest.save()
            print(f"Updated image for restaurant: {name} -> {img_path}")
        except Restaurant.DoesNotExist:
            print(f"Restaurant {name} not found")

    # 2. Update MenuItem images
    menu_items_images = {
        # Pizza Palace items
        "Margherita Classica": "menu_items/margherita_pizza.png",
        "Pepperoni Feast": "menu_items/margherita_pizza.png",
        "Garden Special Veggie": "menu_items/margherita_pizza.png",
        "Garlic Breadsticks": "menu_items/margherita_pizza.png",
        
        # Burger Bistro items
        "Classic Cheeseburger": "menu_items/gourmet_burger.png",
        "Spicy Crispy Chicken Burger": "menu_items/gourmet_burger.png",
        "Double Trouble Smash Burger": "menu_items/gourmet_burger.png",
        "Ultimate Veggie Delight Burger": "menu_items/gourmet_burger.png",
        "Warm Chocolate Fudge Brownie": "menu_items/gourmet_burger.png",

        # The Green Garden items
        "Avocado & Quinoa Power Bowl": "menu_items/quinoa_salad.png",
        "Mediterranean Caesar Salad": "menu_items/quinoa_salad.png",
        "Cold-Pressed Green Juice": "menu_items/quinoa_salad.png",
        "Vegan Chia Seed Pudding": "menu_items/quinoa_salad.png",

        # Sushi Express items
        "Salmon Avocado Roll (8 pcs)": "menu_items/salmon_sushi.png",
        "California Gold Roll (8 pcs)": "menu_items/salmon_sushi.png",
        "Crunchy Veggie Tempura Roll (8 pcs)": "menu_items/salmon_sushi.png",
    }

    for name, img_path in menu_items_images.items():
        try:
            items = MenuItem.objects.filter(name=name)
            for item in items:
                item.image = img_path
                item.save()
                print(f"Updated image for menu item: {name} ({item.restaurant.name}) -> {img_path}")
        except Exception as e:
            print(f"Error updating menu item {name}: {e}")

    print("All restaurant and menu item images updated successfully!")

if __name__ == '__main__':
    update_db_images()

