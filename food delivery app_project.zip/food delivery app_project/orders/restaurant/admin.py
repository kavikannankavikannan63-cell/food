from django.contrib import admin
from .models import Category, Restaurant, MenuItem


@admin.register(Category)
class CategoryAdmin(admin.ModelAdmin):
    list_display = ('name', 'icon', 'slug')
    prepopulated_fields = {'slug': ('name',)}


@admin.register(Restaurant)
class RestaurantAdmin(admin.ModelAdmin):
    list_display = ('name', 'rating', 'delivery_time', 'is_active', 'created_at')
    list_filter = ('is_active',)
    search_fields = ('name', 'address')


@admin.register(MenuItem)
class MenuItemAdmin(admin.ModelAdmin):
    list_display = ('name', 'restaurant', 'category', 'price', 'is_available', 'is_featured')
    list_filter = ('is_available', 'is_featured', 'is_vegetarian', 'category', 'restaurant')
    search_fields = ('name', 'description')
