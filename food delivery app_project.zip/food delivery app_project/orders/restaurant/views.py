from django.shortcuts import render, get_object_or_404, redirect
from django.db.models import Q
from .models import Category, MenuItem, Restaurant


def home(request):
    """Homepage – featured items, categories and restaurants."""
    categories = Category.objects.all()
    restaurants = Restaurant.objects.filter(is_active=True)[:6]
    featured_items = MenuItem.objects.filter(is_featured=True, is_available=True)[:8]
    all_items = MenuItem.objects.filter(is_available=True)[:12]
    context = {
        'categories': categories,
        'restaurants': restaurants,
        'featured_items': featured_items,
        'all_items': all_items,
    }
    return render(request, 'restaurant/home.html', context)


def menu_list(request):
    """Full menu with search & category filter."""
    query = request.GET.get('q', '')
    category_slug = request.GET.get('category', '')
    categories = Category.objects.all()
    items = MenuItem.objects.filter(is_available=True)

    if query:
        items = items.filter(Q(name__icontains=query) | Q(description__icontains=query))
    if category_slug:
        items = items.filter(category__slug=category_slug)

    context = {
        'items': items,
        'categories': categories,
        'selected_category': category_slug,
        'query': query,
    }
    return render(request, 'restaurant/menu_list.html', context)


def menu_item_detail(request, pk):
    """Single menu item detail page."""
    item = get_object_or_404(MenuItem, pk=pk, is_available=True)
    related_items = MenuItem.objects.filter(
        category=item.category, is_available=True
    ).exclude(pk=pk)[:4]
    return render(request, 'restaurant/menu_item_detail.html', {
        'item': item,
        'related_items': related_items,
    })


def restaurant_list(request):
    """All active restaurants."""
    restaurants = Restaurant.objects.filter(is_active=True)
    return render(request, 'restaurant/restaurant_list.html', {'restaurants': restaurants})


def restaurant_detail(request, pk):
    """A single restaurant with its menu."""
    restaurant = get_object_or_404(Restaurant, pk=pk, is_active=True)
    categories = Category.objects.filter(items__restaurant=restaurant).distinct()
    menu_items = restaurant.menu_items.filter(is_available=True)
    return render(request, 'restaurant/restaurant_detail.html', {
        'restaurant': restaurant,
        'categories': categories,
        'menu_items': menu_items,
    })
