import React, { useState, useEffect } from 'react';
import { Wind, LogOut, Shield, ShieldAlert, ShieldCheck, RefreshCw, BarChart3, Sliders, Info, Download, Trash2 } from 'lucide-react';

function Dashboard({ user, onLogout }) {
  // Environmental simulation factors
  const [traffic, setTraffic] = useState(50); // %
  const [industry, setIndustry] = useState(40); // %
  const [windSpeed, setWindSpeed] = useState(15); // km/h
  const [temperature, setTemperature] = useState(25); // °C

  // State for pollutants
  const [pm25, setPm25] = useState(0);
  const [pm10, setPm10] = useState(0);
  const [co, setCo] = useState(0);
  const [no2, setNo2] = useState(0);
  const [so2, setSo2] = useState(0);
  const [o3, setO3] = useState(0);
  const [aqi, setAqi] = useState(0);

  // History for visualizations (dynamic array)
  const [history, setHistory] = useState([]);
  const [city, setCity] = useState('Metro Area');

  // Math engine: recalculate air quality parameters when sliders change
  useEffect(() => {
    // 1. Base values
    const basePM25 = 12;
    const basePM10 = 20;
    const baseCO = 0.3;
    const baseNO2 = 10;
    const baseSO2 = 2;
    const baseO3 = 25;

    // 2. Add traffic impact
    let calcPM25 = basePM25 + (traffic * 0.95);
    let calcPM10 = basePM10 + (traffic * 0.75);
    let calcCO = baseCO + (traffic * 0.03);
    let calcNO2 = baseNO2 + (traffic * 0.8);

    // 3. Add industrial impact
    calcPM25 += (industry * 0.85);
    calcPM10 += (industry * 1.35);
    calcSO2 += (industry * 0.6);
    calcNO2 += (industry * 0.3);

    // 4. Add temperature impact (high heat accelerates photochemical smog / O3)
    let calcO3 = baseO3 + (temperature * 0.9) + (traffic * 0.2);

    // 5. Wind mitigation factor (high wind disperses pollutants)
    const dispersion = 1 / (1 + (windSpeed * 0.06));
    
    calcPM25 = Math.round(calcPM25 * dispersion);
    calcPM10 = Math.round(calcPM10 * dispersion);
    calcCO = parseFloat((calcCO * dispersion).toFixed(2));
    calcNO2 = Math.round(calcNO2 * dispersion);
    calcSO2 = Math.round(calcSO2 * dispersion);
    calcO3 = Math.round(calcO3 * dispersion);

    // 6. Compute AQI using a simplified formula (max of sub-indices)
    // Normally sub-indices are calculated using US EPA standard breakpoints.
    // Here we compute sub-indexes normalized on a 0-500 scale for simplicity.
    const iPM25 = (calcPM25 / 120) * 150;
    const iPM10 = (calcPM10 / 150) * 150;
    const iNO2 = (calcNO2 / 100) * 150;
    const iO3 = (calcO3 / 120) * 150;

    const calculatedAqi = Math.round(Math.max(iPM25, iPM10, iNO2, iO3, 10));
    const finalAqi = Math.min(calculatedAqi, 500);

    setPm25(calcPM25);
    setPm10(calcPM10);
    setCo(calcCO);
    setNo2(calcNO2);
    setSo2(calcSO2);
    setO3(calcO3);
    setAqi(finalAqi);
  }, [traffic, industry, windSpeed, temperature]);

  // Log historical data point on user action or auto-update
  const handleLogData = () => {
    const timestamp = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
    const newDataPoint = {
      timestamp,
      aqi,
      pm25,
      pm10,
      no2,
      o3,
    };
    setHistory((prev) => [...prev.slice(-9), newDataPoint]); // Keep last 10 records
  };

  // Populate initial demo history
  useEffect(() => {
    const initialHistory = [];
    for (let i = 8; i >= 0; i--) {
      const time = new Date();
      time.setMinutes(time.getMinutes() - i * 15);
      const timestamp = time.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
      // Generate realistic fluctuating historical data points
      const variance = Math.sin(i) * 15;
      const histAqi = Math.round(Math.max(aqi - variance, 20));
      initialHistory.push({
        timestamp,
        aqi: histAqi,
        pm25: Math.round(Math.max(pm25 - variance * 0.4, 5)),
        pm10: Math.round(Math.max(pm10 - variance * 0.6, 10)),
        no2: Math.round(Math.max(no2 - variance * 0.3, 2)),
        o3: Math.round(Math.max(o3 - variance * 0.3, 15)),
      });
    }
    setHistory(initialHistory);
  }, [pm25]); // run once initial values populate

  // Reset simulation sliders to defaults
  const handleResetSimulation = () => {
    setTraffic(50);
    setIndustry(40);
    setWindSpeed(15);
    setTemperature(25);
  };

  // Get AQI Status and Style mapping
  const getAqiDetails = (val) => {
    if (val <= 50) return { label: 'Good', color: 'var(--aqi-good)', text: '#064e3b', bg: '#d1fae5', advice: 'Air quality is satisfactory. Outdoor activities are safe for all.' };
    if (val <= 100) return { label: 'Moderate', color: 'var(--aqi-moderate)', text: '#713f12', bg: '#fef9c3', advice: 'Acceptable air quality. Extremely sensitive individuals should limit heavy outdoor work.' };
    if (val <= 150) return { label: 'Sensitive', color: 'var(--aqi-unhealthy-sensitive)', text: '#7c2d12', bg: '#ffedd5', advice: 'Members of sensitive groups may experience health effects. General public not likely affected.' };
    if (val <= 200) return { label: 'Unhealthy', color: 'var(--aqi-unhealthy)', text: '#7f1d1d', bg: '#fee2e2', advice: 'Active children, adults, and people with respiratory disease should avoid prolonged outdoor exertion.' };
    if (val <= 300) return { label: 'Very Unhealthy', color: 'var(--aqi-very-unhealthy)', text: '#581c87', bg: '#f3e8ff', advice: 'Health alert: everyone may experience more serious health effects. Keep windows closed.' };
    return { label: 'Hazardous', color: 'var(--aqi-hazardous)', text: '#ffffff', bg: '#7f1d1d', advice: 'Emergency health warnings. Everyone must avoid all outdoor physical activity.' };
  };

  const aqiInfo = getAqiDetails(aqi);

  // CSV Exporter
  const exportToCSV = () => {
    const headers = ['Timestamp', 'AQI', 'PM2.5 (ug/m3)', 'PM10 (ug/m3)', 'NO2 (ppb)', 'O3 (ppb)'];
    const rows = history.map(h => [h.timestamp, h.aqi, h.pm25, h.pm10, h.no2, h.o3]);
    let csvContent = "data:text/csv;charset=utf-8," 
      + [headers.join(','), ...rows.map(e => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `aeropulse_aqi_data_${Date.now()}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="dashboard-layout">
      {/* Navigation bar */}
      <nav className="dashboard-nav">
        <div className="dashboard-nav-logo">
          <Wind size={24} />
          <span>AeroPulse Analytics</span>
        </div>
        <div className="dashboard-nav-profile">
          <select 
            value={city} 
            onChange={(e) => setCity(e.target.value)}
            style={{
              background: 'rgba(15, 23, 42, 0.6)',
              border: '1px solid var(--glass-border)',
              color: 'var(--text-primary)',
              borderRadius: 'var(--radius-sm)',
              padding: '0.3rem 0.8rem',
              outline: 'none',
              cursor: 'pointer'
            }}
          >
            <option value="Metro Area">Metro Area</option>
            <option value="Industrial Zone">Industrial Zone</option>
            <option value="Coastal suburb">Coastal Suburb</option>
            <option value="Mountain station">Mountain Station</option>
          </select>
          <span className="user-badge">{user.name}</span>
          <button className="logout-btn" onClick={onLogout} title="Log Out">
            <span style={{ display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
              <LogOut size={16} /> Logout
            </span>
          </button>
        </div>
      </nav>

      {/* Main Content Area */}
      <main className="dashboard-content">
        
        {/* Top summary panel */}
        <div className="dashboard-grid">
          
          {/* Main AQI gauge */}
          <div className="metric-card aqi-gauge-card" style={{ gridColumn: 'span 2' }}>
            <div className="aqi-circle-container">
              <div 
                className="aqi-circle" 
                style={{ borderColor: aqiInfo.color }}
              >
                <span className="aqi-number" style={{ color: aqiInfo.color }}>{aqi}</span>
                <span className="aqi-label" style={{ color: aqiInfo.color }}>AQI</span>
              </div>
              
              {/* Outer glow aura based on severity */}
              <div 
                style={{
                  position: 'absolute',
                  width: '200px',
                  height: '200px',
                  borderRadius: '50%',
                  background: aqiInfo.color,
                  filter: 'blur(30px)',
                  opacity: 0.15,
                  zIndex: 1
                }}
              />
            </div>
            
            <div className="aqi-description-panel">
              <div className="metric-header">
                <span>STATION INDEX: {city}</span>
                <span style={{ color: 'var(--text-muted)' }}>LIVE MODEL</span>
              </div>
              <h2 style={{ fontSize: '1.8rem', fontWeight: 800 }}>Air Quality Status</h2>
              <div 
                className="aqi-status-pill" 
                style={{ background: aqiInfo.bg, color: aqiInfo.text }}
              >
                {aqiInfo.label}
              </div>
              <p className="aqi-health-advice">
                {aqiInfo.advice}
              </p>
              
              <div style={{ display: 'flex', gap: '1rem', marginTop: '0.5rem' }}>
                <button 
                  onClick={handleLogData}
                  style={{
                    padding: '0.5rem 1rem',
                    background: 'rgba(255, 255, 255, 0.05)',
                    border: '1px solid var(--glass-border)',
                    borderRadius: 'var(--radius-sm)',
                    color: 'var(--text-primary)',
                    cursor: 'pointer',
                    display: 'inline-flex',
                    alignItems: 'center',
                    gap: '0.5rem',
                    fontSize: '0.85rem'
                  }}
                  onMouseOver={(e) => e.target.style.background = 'rgba(255, 255, 255, 0.1)'}
                  onMouseOut={(e) => e.target.style.background = 'rgba(255, 255, 255, 0.05)'}
                >
                  <RefreshCw size={14} /> Log Data Point
                </button>
              </div>
            </div>
          </div>

          {/* Environmental factors quick indicators */}
          <div className="metric-card">
            <div className="metric-header">
              <span>WIND IMPACT</span>
              <Wind size={18} style={{ color: 'var(--accent-cyan)' }} />
            </div>
            <div className="metric-value">
              {windSpeed} <span className="metric-unit">km/h</span>
            </div>
            <div className="metric-footer">
              <span>Mitigative air circulation active.</span>
            </div>
          </div>

          <div className="metric-card">
            <div className="metric-header">
              <span>TEMPERATURE</span>
              <Info size={18} style={{ color: 'var(--accent-purple)' }} />
            </div>
            <div className="metric-value">
              {temperature}<span className="metric-unit">°C</span>
            </div>
            <div className="metric-footer">
              <span>Direct catalyst for photo-smog O3.</span>
            </div>
          </div>

        </div>

        {/* Dynamic Pollutants grid */}
        <div className="dashboard-grid" style={{ gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))' }}>
          
          <div className="metric-card">
            <span style={{ fontSize: '0.8rem', color: 'var(--text-secondary)', fontWeight: 600 }}>PM2.5</span>
            <div style={{ fontSize: '1.8rem', fontWeight: 800 }}>
              {pm25} <span className="metric-unit">μg/m³</span>
            </div>
            <div style={{ height: '4px', background: 'var(--bg-tertiary)', borderRadius: '2px', overflow: 'hidden' }}>
              <div style={{ height: '100%', background: pm25 > 55 ? 'var(--aqi-unhealthy)' : 'var(--aqi-good)', width: `${Math.min((pm25/120)*100, 100)}%` }} />
            </div>
            <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Fine respirables</span>
          </div>

          <div className="metric-card">
            <span style={{ fontSize: '0.8rem', color: 'var(--text-secondary)', fontWeight: 600 }}>PM10</span>
            <div style={{ fontSize: '1.8rem', fontWeight: 800 }}>
              {pm10} <span className="metric-unit">μg/m³</span>
            </div>
            <div style={{ height: '4px', background: 'var(--bg-tertiary)', borderRadius: '2px', overflow: 'hidden' }}>
              <div style={{ height: '100%', background: pm10 > 150 ? 'var(--aqi-unhealthy)' : 'var(--aqi-good)', width: `${Math.min((pm10/250)*100, 100)}%` }} />
            </div>
            <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Coarse dust particles</span>
          </div>

          <div className="metric-card">
            <span style={{ fontSize: '0.8rem', color: 'var(--text-secondary)', fontWeight: 600 }}>NO₂</span>
            <div style={{ fontSize: '1.8rem', fontWeight: 800 }}>
              {no2} <span className="metric-unit">ppb</span>
            </div>
            <div style={{ height: '4px', background: 'var(--bg-tertiary)', borderRadius: '2px', overflow: 'hidden' }}>
              <div style={{ height: '100%', background: no2 > 100 ? 'var(--aqi-unhealthy)' : 'var(--aqi-good)', width: `${Math.min((no2/200)*100, 100)}%` }} />
            </div>
            <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Nitrogen dioxide (Traffic)</span>
          </div>

          <div className="metric-card">
            <span style={{ fontSize: '0.8rem', color: 'var(--text-secondary)', fontWeight: 600 }}>O₃</span>
            <div style={{ fontSize: '1.8rem', fontWeight: 800 }}>
              {o3} <span className="metric-unit">ppb</span>
            </div>
            <div style={{ height: '4px', background: 'var(--bg-tertiary)', borderRadius: '2px', overflow: 'hidden' }}>
              <div style={{ height: '100%', background: o3 > 120 ? 'var(--aqi-unhealthy)' : 'var(--aqi-good)', width: `${Math.min((o3/180)*100, 100)}%` }} />
            </div>
            <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Ground-level ozone</span>
          </div>

          <div className="metric-card">
            <span style={{ fontSize: '0.8rem', color: 'var(--text-secondary)', fontWeight: 600 }}>SO₂</span>
            <div style={{ fontSize: '1.8rem', fontWeight: 800 }}>
              {so2} <span className="metric-unit">ppb</span>
            </div>
            <div style={{ height: '4px', background: 'var(--bg-tertiary)', borderRadius: '2px', overflow: 'hidden' }}>
              <div style={{ height: '100%', background: so2 > 75 ? 'var(--aqi-unhealthy)' : 'var(--aqi-good)', width: `${Math.min((so2/150)*100, 100)}%` }} />
            </div>
            <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Sulfur dioxide (Industry)</span>
          </div>

          <div className="metric-card">
            <span style={{ fontSize: '0.8rem', color: 'var(--text-secondary)', fontWeight: 600 }}>CO</span>
            <div style={{ fontSize: '1.8rem', fontWeight: 800 }}>
              {co} <span className="metric-unit">ppm</span>
            </div>
            <div style={{ height: '4px', background: 'var(--bg-tertiary)', borderRadius: '2px', overflow: 'hidden' }}>
              <div style={{ height: '100%', background: co > 9 ? 'var(--aqi-unhealthy)' : 'var(--aqi-good)', width: `${Math.min((co/15)*100, 100)}%` }} />
            </div>
            <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Carbon Monoxide</span>
          </div>

        </div>

        {/* Interactive Controls & Chart Section */}
        <div className="simulation-panel">
          
          {/* Simulation Slider Inputs */}
          <div className="glass-container">
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1.5rem' }}>
              <h3 style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', fontSize: '1.25rem', fontWeight: 700 }}>
                <Sliders size={20} style={{ color: 'var(--accent-cyan)' }} />
                Environment Simulator
              </h3>
              <button 
                onClick={handleResetSimulation}
                style={{
                  background: 'transparent',
                  border: 'none',
                  color: 'var(--accent-cyan)',
                  cursor: 'pointer',
                  fontSize: '0.85rem',
                  fontWeight: 600
                }}
              >
                Reset Defaults
              </button>
            </div>

            {/* Slider: Traffic Density */}
            <div className="slider-group">
              <div className="slider-header">
                <span>Traffic Volume</span>
                <span>{traffic}%</span>
              </div>
              <input 
                type="range" 
                min="0" 
                max="100" 
                value={traffic} 
                onChange={(e) => setTraffic(parseInt(e.target.value))}
                className="slider-input" 
              />
              <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Impacts PM2.5, PM10, CO, & NO₂ levels</span>
            </div>

            {/* Slider: Industrial Output */}
            <div className="slider-group">
              <div className="slider-header">
                <span>Industrial Emissions</span>
                <span>{industry}%</span>
              </div>
              <input 
                type="range" 
                min="0" 
                max="100" 
                value={industry} 
                onChange={(e) => setIndustry(parseInt(e.target.value))}
                className="slider-input" 
              />
              <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Impacts PM10, PM2.5, & SO₂ levels</span>
            </div>

            {/* Slider: Wind Speed */}
            <div className="slider-group">
              <div className="slider-header">
                <span>Wind Velocity</span>
                <span>{windSpeed} km/h</span>
              </div>
              <input 
                type="range" 
                min="0" 
                max="50" 
                value={windSpeed} 
                onChange={(e) => setWindSpeed(parseInt(e.target.value))}
                className="slider-input" 
              />
              <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Higher wind disperses and dilutes pollutants</span>
            </div>

            {/* Slider: Temperature */}
            <div className="slider-group">
              <div className="slider-header">
                <span>Air Temperature</span>
                <span>{temperature}°C</span>
              </div>
              <input 
                type="range" 
                min="0" 
                max="50" 
                value={temperature} 
                onChange={(e) => setTemperature(parseInt(e.target.value))}
                className="slider-input" 
              />
              <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Higher temp drives ground-level Ozone (O₃) generation</span>
            </div>
          </div>

          {/* Dynamic Trend Chart */}
          <div className="glass-container">
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1.5rem' }}>
              <h3 style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', fontSize: '1.25rem', fontWeight: 700 }}>
                <BarChart3 size={20} style={{ color: 'var(--accent-purple)' }} />
                Historical AQI Trend (Logged Data)
              </h3>
              <div style={{ display: 'flex', gap: '0.5rem' }}>
                <button 
                  onClick={exportToCSV}
                  disabled={history.length === 0}
                  style={{
                    background: 'transparent',
                    border: '1px solid var(--glass-border)',
                    padding: '0.2rem 0.5rem',
                    borderRadius: '4px',
                    color: history.length === 0 ? 'var(--text-muted)' : 'var(--text-primary)',
                    cursor: history.length === 0 ? 'not-allowed' : 'pointer',
                    display: 'flex',
                    alignItems: 'center',
                    gap: '0.25rem',
                    fontSize: '0.75rem'
                  }}
                  title="Export to CSV"
                >
                  <Download size={12} /> CSV
                </button>
                <button 
                  onClick={() => setHistory([])}
                  style={{
                    background: 'transparent',
                    border: '1px solid rgba(244,63,94,0.2)',
                    padding: '0.2rem 0.5rem',
                    borderRadius: '4px',
                    color: 'var(--accent-rose)',
                    cursor: 'pointer',
                    display: 'flex',
                    alignItems: 'center',
                    gap: '0.25rem',
                    fontSize: '0.75rem'
                  }}
                  title="Clear history"
                >
                  <Trash2 size={12} /> Clear
                </button>
              </div>
            </div>

            {history.length === 0 ? (
              <div style={{ height: '320px', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', color: 'var(--text-muted)' }}>
                <Info size={32} style={{ marginBottom: '1rem' }} />
                <span>No logged points. Adjust sliders and click "Log Data Point" to build trend chart.</span>
              </div>
            ) : (
              <div className="chart-container">
                {history.map((pt, idx) => {
                  // Normalize height percentage relative to a max index of 350
                  const heightPercent = Math.max(Math.min((pt.aqi / 350) * 100, 100), 4);
                  const barColor = getAqiDetails(pt.aqi).color;
                  return (
                    <div className="chart-bar-col" key={idx}>
                      <div 
                        className="chart-bar" 
                        style={{ 
                          height: `${heightPercent}%`,
                          background: `linear-gradient(to top, var(--bg-tertiary), ${barColor})`
                        }}
                      >
                        <div className="chart-bar-tooltip">
                          AQI: {pt.aqi}<br />
                          PM2.5: {pt.pm25}
                        </div>
                      </div>
                      <div className="chart-label">{pt.timestamp}</div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

        </div>

        {/* Data Log Table */}
        {history.length > 0 && (
          <div className="glass-container" style={{ overflowX: 'auto' }}>
            <h3 style={{ fontSize: '1.1rem', fontWeight: 700, marginBottom: '1rem' }}>Terminal Data Log Stream</h3>
            <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '0.9rem', textAlign: 'left' }}>
              <thead>
                <tr style={{ borderBottom: '1px solid var(--glass-border)', color: 'var(--text-secondary)' }}>
                  <th style={{ padding: '0.75rem 0.5rem' }}>Timestamp</th>
                  <th style={{ padding: '0.75rem 0.5rem' }}>AQI</th>
                  <th style={{ padding: '0.75rem 0.5rem' }}>PM2.5</th>
                  <th style={{ padding: '0.75rem 0.5rem' }}>PM10</th>
                  <th style={{ padding: '0.75rem 0.5rem' }}>NO₂</th>
                  <th style={{ padding: '0.75rem 0.5rem' }}>O₃</th>
                  <th style={{ padding: '0.75rem 0.5rem' }}>Health Status</th>
                </tr>
              </thead>
              <tbody>
                {history.map((pt, idx) => {
                  const details = getAqiDetails(pt.aqi);
                  return (
                    <tr key={idx} style={{ borderBottom: '1px dotted rgba(255,255,255,0.03)' }}>
                      <td style={{ padding: '0.75rem 0.5rem', fontFamily: 'monospace' }}>{pt.timestamp}</td>
                      <td style={{ padding: '0.75rem 0.5rem', fontWeight: 700, color: details.color }}>{pt.aqi}</td>
                      <td style={{ padding: '0.75rem 0.5rem' }}>{pt.pm25} μg/m³</td>
                      <td style={{ padding: '0.75rem 0.5rem' }}>{pt.pm10} μg/m³</td>
                      <td style={{ padding: '0.75rem 0.5rem' }}>{pt.no2} ppb</td>
                      <td style={{ padding: '0.75rem 0.5rem' }}>{pt.o3} ppb</td>
                      <td style={{ padding: '0.75rem 0.5rem' }}>
                        <span 
                          style={{
                            padding: '0.1rem 0.5rem',
                            borderRadius: '3px',
                            background: details.bg,
                            color: details.text,
                            fontSize: '0.75rem',
                            fontWeight: 700
                          }}
                        >
                          {details.label}
                        </span>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}

      </main>
    </div>
  );
}

export default Dashboard;
