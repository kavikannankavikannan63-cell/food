import React, { useState } from 'react';
import { Wind, Mail, Lock, Eye, EyeOff, ShieldAlert, CheckCircle2 } from 'lucide-react';

function Login({ onLoginSuccess }) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = (e) => {
    e.preventDefault();
    setError('');
    setSuccess('');

    // Basic Validation
    if (!email) {
      setError('Email address is required.');
      return;
    }
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      setError('Please enter a valid email address.');
      return;
    }
    if (!password) {
      setError('Password is required.');
      return;
    }
    if (password.length < 6) {
      setError('Password must be at least 6 characters long.');
      return;
    }

    // Simulate Authentication
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      // Hardcoded login for demonstration
      if (email === 'admin@aeropulse.com' && password === 'admin123') {
        setSuccess('Authentication successful! Loading dashboard...');
        setTimeout(() => {
          onLoginSuccess({ email, name: 'Lead Analyst' });
        }, 1000);
      } else {
        setError('Invalid email or password. Hint: Use admin@aeropulse.com / admin123');
      }
    }, 1200);
  };

  const handleFillDemo = () => {
    setEmail('admin@aeropulse.com');
    setPassword('admin123');
    setError('');
  };

  return (
    <div className="login-wrapper">
      <div className="login-card glass-container">
        
        {/* Logo Section */}
        <div className="login-logo">
          <Wind size={36} />
          <span className="login-logo-text">AeroPulse</span>
        </div>

        {/* Title/Header */}
        <div className="login-header">
          <h2 className="login-title">Environmental Analytics Portal</h2>
          <p className="login-subtitle">Sign in to access real-time data & dynamic simulation models.</p>
        </div>

        {/* Feedback Messages */}
        {error && (
          <div className="alert-box alert-error">
            <ShieldAlert size={20} style={{ flexShrink: 0 }} />
            <span>{error}</span>
          </div>
        )}

        {success && (
          <div className="alert-box alert-success">
            <CheckCircle2 size={20} style={{ flexShrink: 0 }} />
            <span>{success}</span>
          </div>
        )}

        {/* Login Form */}
        <form onSubmit={handleSubmit} noValidate>
          {/* Email input */}
          <div className="input-group">
            <label className="input-label" htmlFor="email-input">Email Address</label>
            <div className="input-wrapper">
              <input
                id="email-input"
                type="email"
                className="form-input"
                placeholder="analyst@aeropulse.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                disabled={loading}
              />
              <Mail className="input-icon" size={18} />
            </div>
          </div>

          {/* Password input */}
          <div className="input-group">
            <label className="input-label" htmlFor="password-input">Password</label>
            <div className="input-wrapper">
              <input
                id="password-input"
                type={showPassword ? 'text' : 'password'}
                className="form-input"
                placeholder="••••••••"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                disabled={loading}
              />
              <Lock className="input-icon" size={18} />
              <button
                type="button"
                className="password-toggle-btn"
                onClick={() => setShowPassword(!showPassword)}
                aria-label={showPassword ? 'Hide password' : 'Show password'}
              >
                {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
              </button>
            </div>
          </div>

          {/* Submit Button */}
          <button type="submit" className="btn-primary" disabled={loading}>
            {loading ? (
              <span className="flex-center" style={{ gap: '0.5rem' }}>
                <svg
                  className="animate-spin"
                  style={{
                    animation: 'rotateBlur 1s linear infinite',
                    width: '18px',
                    height: '18px'
                  }}
                  viewBox="0 0 24 24"
                  fill="none"
                >
                  <circle
                    cx="12"
                    cy="12"
                    r="10"
                    stroke="currentColor"
                    strokeWidth="4"
                    style={{ opacity: 0.25 }}
                  />
                  <path
                    fill="currentColor"
                    d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                  />
                </svg>
                Verifying Credentials...
              </span>
            ) : (
              'Access Terminal'
            )}
          </button>
        </form>

        {/* Demo Hint Banner */}
        <div 
          onClick={handleFillDemo}
          style={{
            marginTop: '2rem',
            padding: '1rem',
            borderRadius: 'var(--radius-md)',
            background: 'rgba(59, 130, 246, 0.08)',
            border: '1px dashed rgba(59, 130, 246, 0.3)',
            cursor: 'pointer',
            textAlign: 'center',
            fontSize: '0.85rem',
            transition: 'all var(--transition-fast)'
          }}
          className="demo-hint-box"
        >
          <div style={{ fontWeight: 700, color: 'var(--accent-blue)', marginBottom: '0.2rem' }}>
            💡 Quick Demo Access
          </div>
          <div style={{ color: 'var(--text-secondary)' }}>
            Click here to auto-fill mock credential: <br />
            <strong>admin@aeropulse.com</strong> / <strong>admin123</strong>
          </div>
        </div>

      </div>

      <style>{`
        .demo-hint-box:hover {
          background: rgba(59, 130, 246, 0.15) !important;
          border-color: var(--accent-cyan) !important;
        }
      `}</style>
    </div>
  );
}

export default Login;
