def cart_count(request):
    """Context processor to expose the cart items count globally in templates."""
    if request.user.is_authenticated:
        try:
            # Cart has a OneToOne relation with CustomUser
            cart = request.user.cart
            return {'cart_count': cart.item_count}
        except Exception:
            return {'cart_count': 0}
    return {'cart_count': 0}
