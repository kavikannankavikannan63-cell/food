import json
from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.http import JsonResponse
from django.views.decorators.http import require_POST
from restaurant.models import MenuItem
from .models import Cart, CartItem, Order, OrderItem


# ─── Cart helpers ────────────────────────────────────────────────────────────

def _get_or_create_cart(user):
    cart, _ = Cart.objects.get_or_create(user=user)
    return cart


# ─── Cart views ──────────────────────────────────────────────────────────────

@login_required
def cart_view(request):
    """Display the shopping cart."""
    cart = _get_or_create_cart(request.user)
    return render(request, 'orders/cart.html', {'cart': cart})


@login_required
@require_POST
def add_to_cart(request, item_id):
    """Add a menu item to the cart (AJAX-friendly)."""
    menu_item = get_object_or_404(MenuItem, pk=item_id, is_available=True)
    cart = _get_or_create_cart(request.user)
    cart_item, created = CartItem.objects.get_or_create(cart=cart, menu_item=menu_item)
    if not created:
        cart_item.quantity += 1
        cart_item.save()

    if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        return JsonResponse({
            'success': True,
            'cart_count': cart.item_count,
            'message': f'"{menu_item.name}" added to cart!',
        })
    messages.success(request, f'"{menu_item.name}" added to your cart!')
    return redirect('cart')


@login_required
@require_POST
def remove_from_cart(request, item_id):
    """Remove an item from the cart."""
    cart_item = get_object_or_404(CartItem, pk=item_id, cart__user=request.user)
    cart_item.delete()
    messages.info(request, 'Item removed from cart.')
    return redirect('cart')


@login_required
@require_POST
def update_cart(request, item_id):
    """Update quantity of a cart item."""
    cart_item = get_object_or_404(CartItem, pk=item_id, cart__user=request.user)
    qty = int(request.POST.get('quantity', 1))
    if qty <= 0:
        cart_item.delete()
        messages.info(request, 'Item removed from cart.')
    else:
        cart_item.quantity = qty
        cart_item.save()
    return redirect('cart')


# ─── Checkout & Orders ───────────────────────────────────────────────────────

@login_required
def checkout(request):
    """Checkout page – collect delivery details."""
    cart = _get_or_create_cart(request.user)
    if not cart.cart_items.exists():
        messages.warning(request, 'Your cart is empty.')
        return redirect('menu_list')

    if request.method == 'POST':
        address = request.POST.get('address', '').strip()
        phone   = request.POST.get('phone', '').strip()
        notes   = request.POST.get('notes', '').strip()

        if not address or not phone:
            messages.error(request, 'Please provide a delivery address and phone number.')
            return render(request, 'orders/checkout.html', {'cart': cart})

        order = Order.objects.create(
            user=request.user,
            delivery_address=address,
            phone=phone,
            notes=notes,
            total_price=cart.total,
        )
        for ci in cart.cart_items.all():
            OrderItem.objects.create(
                order=order,
                menu_item=ci.menu_item,
                quantity=ci.quantity,
                price=ci.menu_item.price,
            )
        cart.cart_items.all().delete()
        messages.success(request, f'Order #{order.pk} placed successfully! 🎉')
        return redirect('order_confirmation', pk=order.pk)

    return render(request, 'orders/checkout.html', {'cart': cart})


@login_required
def order_confirmation(request, pk):
    """Order placed – confirmation page."""
    order = get_object_or_404(Order, pk=pk, user=request.user)
    return render(request, 'orders/order_confirmation.html', {'order': order})


@login_required
def order_list(request):
    """All orders for the logged-in user."""
    orders = Order.objects.filter(user=request.user)
    return render(request, 'orders/order_list.html', {'orders': orders})


@login_required
def order_detail(request, pk):
    """Detail of a single order."""
    order = get_object_or_404(Order, pk=pk, user=request.user)
    return render(request, 'orders/order_detail.html', {'order': order})
